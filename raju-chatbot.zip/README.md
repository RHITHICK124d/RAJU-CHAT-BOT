# Raju Chatbot 😎

A sarcastic and funny personal chatbot that only replies if you call him "Raju".

## Features
- Responds only if you say "Raju"
- Remembers your name
- Friendly Tamil-English tone
- Terminal interface
- Easily extendable with new rules

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/raju-chatbot.git
cd raju-chatbot
python interface/terminal_ui.py
```

## License
MIT
