from app.chatbot import RajuChatbot

def run():
    raju = RajuChatbot()
    print("😎 Welcome to Raju Chatbot Terminal 😎\n(Type 'exit' to quit)\n")

    while True:
        msg = input("You: ")
        if msg.lower() == "exit":
            print("Raju: Seri da... Bye 👋")
            break
        reply = raju.chat(msg)
        print("Raju:", reply)

if __name__ == "__main__":
    run()
