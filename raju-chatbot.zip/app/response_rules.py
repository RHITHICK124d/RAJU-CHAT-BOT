import random

def generate_response(message, name):
    replies = {
        "hello": [f"Vanakkam da {name} 😎", "Solla machi 😏", "Ithu varaikum busy ah irundhen!"],
        "how are you": ["Naan super da, nee eppadi? 🤔", "Boring ah iruku da..."],
        "bye": ["Seri da, odi po 😪", "Naanum thoonguren. See you 😴"],
        "default": [f"Sari {name}... but naan puriyala 🤨", "Adha sollra mathiri illa da."]
    }

    for key in replies:
        if key in message.lower():
            return random.choice(replies[key])

    return random.choice(replies["default"])
