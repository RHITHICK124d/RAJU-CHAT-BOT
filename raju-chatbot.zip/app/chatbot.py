import json
from app.response_rules import generate_response

class RajuChatbot:
    def __init__(self, memory_file='app/memory.json'):
        self.memory_file = memory_file
        self.load_memory()

    def load_memory(self):
        try:
            with open(self.memory_file, 'r') as f:
                self.memory = json.load(f)
        except:
            self.memory = {"user_name": None}

    def save_memory(self):
        with open(self.memory_file, 'w') as f:
            json.dump(self.memory, f)

    def chat(self, message):
        if "raju" not in message.lower():
            return "Poda dai 😏 First say my name — *RAJU!*"

        if self.memory["user_name"] is None and "name is" in message.lower():
            name = message.split("is")[-1].strip().split()[0]
            self.memory["user_name"] = name
            self.save_memory()
            return f"Seri {name} da... naan unakku enna help pannanum? 😎"

        return generate_response(message, self.memory["user_name"])
